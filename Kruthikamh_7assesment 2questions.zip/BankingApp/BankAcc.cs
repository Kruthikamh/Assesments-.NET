﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp
{
        interface ISavingAcc
        {
            double CalSavingsInterset(double bal);
        }
        interface ICurrentAcc
        {
            double CalCurrentInterset(double bal);
        }
        interface IGoldLoanAcc
        {
            double GoldLoanInterset(double capitalamm);
        }
        class BankAcc: ISavingAcc, ICurrentAcc, IGoldLoanAcc
        {
            public double CalSavingsInterset(double bal)
            {
                double interset = 0.05;
                return bal* interset;
            }
            public double CalCurrentInterset(double bal)
            {
                double interset = 0.03;
                return bal* interset;
            }
            public double GoldLoanInterset(double capitalamm)
            {
                double interset = 0.04;
                return capitalamm* interset;
            }

        }
    }


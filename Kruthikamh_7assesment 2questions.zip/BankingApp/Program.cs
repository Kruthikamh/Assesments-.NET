﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAcc acc = new BankAcc();

            Console.WriteLine(" Select an account Type:");
            Console.WriteLine("savings account");
            Console.WriteLine("Current account");
            Console.WriteLine("gold Loan account");
            int choice = int.Parse(Console.ReadLine());

            double result=0.0;
            switch (choice)
            {
                case 1:
                    Console.WriteLine("enter your balance ammount");
                    double mysavings = double.Parse(Console.ReadLine());
                    result = acc.CalSavingsInterset(mysavings);
                    break;
                 case 2:
                    Console.WriteLine("enter your current account balance ammount");
                    double mycurrent = double.Parse(Console.ReadLine());
                    result = acc.CalCurrentInterset(mycurrent);
                    break;
                 case 3:
                    Console.WriteLine("enter your captialammount");
                    double mycaptial= double.Parse(Console.ReadLine());
                    result = acc.CalCurrentInterset(mycaptial);
                    break;

                default: Console.WriteLine("wrong choice");
                    break;
            }
            Console.WriteLine("My Ammount:" +result);
            Console.ReadLine();



        }
    }
}

